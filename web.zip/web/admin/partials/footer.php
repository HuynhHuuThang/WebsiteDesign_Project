<!-- Footers Section Starts -->
<div class="footer">
            <div class="wrapper">
            <p class="text-center">2022 All rights reserved, Some Restaurant. Developed By - <a href="#">Huynh Huu Thang</a>, <a href="#">Vu Minh Khanh</a>, and <a href="#">Tran Thanh Truc</a>.
        </p>
            </div>
        </div>
         <!-- Footers Section Ends -->
    </body>
</html>